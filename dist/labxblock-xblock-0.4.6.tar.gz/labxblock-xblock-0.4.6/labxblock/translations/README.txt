# Configuration for i18n workflow.

locales:
    - en  # English - Source Language
